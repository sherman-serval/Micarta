<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Para ti 💌</title>
  <style>
    body {
      background: #ffe6ec;
      color: #333;
      font-family: 'Courier New', monospace;
      text-align: center;
      padding: 50px;
    }
    h1 {
      color: #d6336c;
    }
    p {
      font-size: 1.2em;
    }
    .heart {
      font-size: 3em;
      color: red;
      animation: beat 1s infinite;
    }
    @keyframes beat {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.2); }
    }
  </style>
</head>
<body>
  <h1>Hola, tú ✨</h1>
  <p>No sé qué somos, pero me inspiras a escribirte.</p>
  <p>Gracias por existir.</p>
  <div class="heart">❤️</div>
</body>
</html>
